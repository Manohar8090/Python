# Write a python Program, which will accept any Value
# and decide whether It is Palindrome or Not
#TernaryOpEx1.py
value=input("Enter Any Value:")
res= "Palindrome" if  value.upper()==value[::-1].upper() else "Not Palindrome"
print("{} is {}".format(value,res))

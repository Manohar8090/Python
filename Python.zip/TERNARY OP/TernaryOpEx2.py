# Write a python Program which will any Numerical Value
# and decide whether It is Even or Odd
#TernaryOpEx2.py
n=float(input("Enter Any Numerical Value:"))
res= "EVEN" if  (n%2==0) else  "ODD"
print("{} is {}".format(n,res))
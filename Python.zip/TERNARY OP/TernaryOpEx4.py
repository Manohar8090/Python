# Write a python Program which will Possitve any Numerical Value
# and decide whether It is Even or Odd
#TernaryOpEx4.py
n=float(input("Enter Any Numerical Value:")) # n=-15
res="EVEN" if (n>0) and (n%2==0) else "ODD" if 0<n%2!=0 else "Invalid Input "
print("{} is {}".format(n,res))
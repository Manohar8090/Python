# Write a python Program which will any  Numerical Value
# and decide whether It is  +VE Or -VE or ZERO
#TernaryOpEx5.py
n=float(input("Enter Any Numerical Value:"))
res="+VE"  if n>0 else "-VE" if n<0 else "ZERO"
print("{} is {}".format(n,res))


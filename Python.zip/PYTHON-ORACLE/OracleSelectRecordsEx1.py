#program for Reading the Records by using fetchone()
#OracleSelectRecordsEx1.py
import oracledb as orc
def recordselect():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        sq="select * from employee"
        curobj.execute(sq)
        print("-"*40)
        while(True):
            record=curobj.fetchone()
            if(record!=None):
                for val in record:
                    print("\t{}".format(val),end="\t")
                print()
            else:
                print("-" * 40)
                break


    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordselect()

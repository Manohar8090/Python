#program for Changing the column sizes of Employee Table
#OracleAlterTableWithModify.py
import oracledb as orc
def tablealterwithmodify():
    try:
        conobj=orc.connect("system/tiger@localhost/orcl") #Step-2
        cur=conobj.cursor() #Step-3
        aq="alter table employee modify(eno number(3),name varchar2(15) not null)"
        cur.execute(aq) #Step-4
        print("Table altered Sucessfully") #Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#main program
tablealterwithmodify()
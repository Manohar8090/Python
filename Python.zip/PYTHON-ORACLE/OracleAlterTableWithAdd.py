#program for adding new column to Employee Table
#OracleAlterTableWithAdd.py
import oracledb as orc
def tablealterwithadd():
    try:
        conobj=orc.connect("system/tiger@localhost/orcl") #Step-2
        cur=conobj.cursor() #Step-3
        aq="alter table employee add(cname varchar2(10) not null)"
        cur.execute(aq) #Step-4
        print("Table altered Sucessfully") #Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#main program
tablealterwithadd()
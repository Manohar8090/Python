#program for Demonstrating the Connection from Oracle database
#OracleConnTest2.py
import oracledb as orc #Step-1
try:
    conobj=orc.connect("system/tiger@127.0.0.1/orcl") # Step-2
    print("---------------------------------------------------")
    print("Python program got connection from Oracle Data base")
    print("Type of conobj=",type(conobj))
    print("---------------------------------------------------")
except orc.DatabaseError as db:
    print("Problem in Oracle: ",db)
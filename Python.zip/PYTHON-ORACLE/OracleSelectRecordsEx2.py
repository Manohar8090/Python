#program for Reading the Records by using fetchmany()
#OracleSelectRecordsEx2.py
import oracledb as orc
def recordselect():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        sq="select * from employee"
        curobj.execute(sq)
        print("-" * 40)
        records=curobj.fetchmany(4)
        for record in records:
            for val in record:
                print("\t{}".format(val),end="\t")
            print()
        print("-" * 40)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordselect()

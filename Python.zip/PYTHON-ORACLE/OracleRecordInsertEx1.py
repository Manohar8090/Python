#program for Inserting a record
#OracleRecordInsertEx1.py
import oracledb as orc
def recordinsert():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        iq="insert into employee values(500,'Kinney',1.5,'pandas')"
        curobj.execute(iq)
        conobj.commit()
        print("Record Inserted")
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordinsert()

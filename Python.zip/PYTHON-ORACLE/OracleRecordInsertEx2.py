#program for Inserting a record
#OracleRecordInsertEx2.py
import oracledb as orc
def recordinsert():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        # accept the employee values from Key board
        print("-"*40)
        empno=int(input("Enter Employee Number: "))
        empname=input("Enter Employee Name: ")
        empsal=float(input("Enter Employee Salary: "))
        empcompname=input("Enter Employee Company Name: ")
        print("-" * 40)
        iq="insert into employee values(%d,'%s',%f,'%s')" % (empno,empname,empsal,empcompname)
        curobj.execute(iq)
        conobj.commit()
        print("{} Record Inserted".format(curobj.rowcount))
        print("-" * 40)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordinsert()

#program for Obtaining the column names of any table
#OracleColumnNamesEx1.py
import oracledb as orc
def columnsselect():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        sq="select * from student"
        curobj.execute(sq)
        records=curobj.fetchall()
        print("-"*50)
        colinfo=curobj.description
        for col in colinfo:
            print("\t{}".format(col[0]),end="\t")
        print()
        print("-" * 50)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
columnsselect()

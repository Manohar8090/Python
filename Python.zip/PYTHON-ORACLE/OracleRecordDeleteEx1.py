#program for deleting the record from Employee table
#OracleRecordDeleteEx1.py
import oracledb as orc
def recorddelete():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        # accept the employee Number for deleting employee record
        print("-"*40)
        empno=int(input("Enter Employee Number for deleting employee record: "))
        dq="delete from employee where eno=%d"
        curobj.execute(dq %empno)
        conobj.commit()
        if(curobj.rowcount>0):
            print("{} Record Deleted".format(curobj.rowcount))
        else:
            print("Employee Number does not exist")
        print("-" * 40)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recorddelete()

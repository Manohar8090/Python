#program for Update a record
#OracleRecordUpdateEx1.py
import oracledb as orc
def recordupdate():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        # accept the employee Number for Updating emp salary
        print("-"*40)
        empno=int(input("Enter Employee Number for Updating emp sal: "))
        empsal=float(input("Enter New Employee Salary: "))
        print("-" * 40)
        uq="update employee set sal=%f where eno=%d"
        curobj.execute(uq % (empsal,empno))
        conobj.commit()
        if(curobj.rowcount>0):
            print("{} Record Updated".format(curobj.rowcount))
        else:
            print("Employee Number does not exist")
        print("-" * 40)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordupdate()

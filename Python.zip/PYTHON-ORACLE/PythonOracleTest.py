#PythonOracleTest.py
import oracledb as orc
print(orc.__version__)
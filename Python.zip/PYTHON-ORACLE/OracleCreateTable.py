#programm for Creating a Table
#OracleCreateTable.py
import oracledb as orc #Step-1
def tablecreate():
    try:
        conobj=orc.connect("system/tiger@localhost/orcl") #Step-2
        cur=conobj.cursor() #Step-3
        tcq="create table teacher(tno number(2) primary key,tname varchar2(10) not null,subject varchar2(10) not null)"
        cur.execute(tcq) #Step-4
        print("Table Created Sucessfully") #Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#main program
tablecreate()
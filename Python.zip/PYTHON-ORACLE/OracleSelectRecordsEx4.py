#program for Reading the Records by using fetchmany()
#OracleSelectRecordsEx3.py
import oracledb as orc
def recordselect():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        sq="select * from employee where eno=%d" %int(input("Enter Employee No: "))
        curobj.execute(sq)
        print("-" * 40)
        record=curobj.fetchone()
        if(record!=None):
            if(len(record)==0):
                print("\ttable does not contain Records")
            else:
                print("\tEmployee Number={}".format(record[0]))
                print("\tEmployee Name={}".format(record[1]))
                print("\tEmployee Salary={}".format(record[2]))
                print("\tEmployee Comp Name={}".format(record[3]))
        else:
            print("\tEmployee Number does not Exist")
        print("-" * 40)
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordselect()

#program for Droping the Table OR Removing the Table
#OracleDropTable.py
import oracledb as orc
def tabledrop():
    try:
        conobj=orc.connect("system/tiger@localhost/orcl") #Step-2
        cur=conobj.cursor() #Step-3
        dtq="drop table teacher"
        cur.execute(dtq) #Step-4
        print("Table Dropped Sucessfully") #Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#main program
tabledrop()
#program for Obtaining Records with Column Names
#OracleRecordsWithColumnNamesEx3.py
import oracledb as orc
def recordswithcolumnsselect():
    try:
        conobj=orc.connect("system/tiger@127.0.0.1/orcl")
        curobj=conobj.cursor()
        sq="select * from employee order by sal desc  "
        curobj.execute(sq)
        records=curobj.fetchall()
        #Get Column Names
        print("-"*50)
        for colname in [col[0] for col in curobj.description]:
            print("\t{}".format(colname),end="\t")
        print()
        print("-" * 50)
        #Get the Records
        for record in records:
            for val in record:
                print("\t{}".format(val), end="\t")
            print()
        print("-" * 50)

    except orc.DatabaseError as db:
        print("Problem in Oracle: ",db)

#Main Program
recordswithcolumnsselect()

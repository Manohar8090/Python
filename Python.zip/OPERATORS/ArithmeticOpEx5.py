#ArithmeticOpEx5.py

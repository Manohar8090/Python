#program for Demionstrating How to Dispencing the Cash interms of 500,200 and 100
#ArithmeticOpEx4.py
wamt=int(input("Enter Withdraw Amount: "))
print("Withdraw Amount: ",wamt)
n500=wamt//500
wamt=wamt%500
n200=wamt//200
wamt=wamt%200
n100=wamt//100
wamt=wamt%100
print("------------------------------")
print("\tNumber of 500s:{}".format(n500))
print("\tNumber of 200s:{}".format(n200))
print("\tNumber of 100s:{}".format(n100))
print("------------------------------")

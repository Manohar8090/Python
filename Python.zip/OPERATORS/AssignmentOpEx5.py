#program for Swapping of Any Two Numerical Integer Values--Logic-5
#AssignmentOpEx4.py
a,b=int(input("Enter Value of a:")),int(input("Enter Value of b:"))
print("-"*50)
print("\tOriginal Val of a={}".format(a))
print("\tOriginal Val of b={}".format(b))
print("-"*50)
a=a^b  # Bitwise XOR (^)
b=a^b
a=a^b
print("\tSwapped Value of a={}".format(a))
print("\tSwapped Value of b={}".format(b))
print("-"*50)

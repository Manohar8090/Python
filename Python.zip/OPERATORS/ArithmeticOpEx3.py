#program for Cal Square Root of a Given Number without using sqrt() of math module
#ArithmeticOpEx3.py
n=float(input("Enter Value of n: "))
sqrtv=n**0.5 # OR sqrtv=n**(1/2)
print("Sqrt({})={}".format(n,sqrtv))
print("--------------OR---------------------")
print("Sqrt({})={}".format(n,round(sqrtv,2)))
#program for Swapping of Any Two Values--Logic-1
#AssignmentOpEx1.py
a,b=input("Enter Value of a:"),input("Enter Value of b:")
print("-"*50)
print("\tOriginal Val of a={}".format(a))
print("\tOriginal Val of b={}".format(b))
print("-"*50)
a,b=b,a # Swapping logic--
print("\tSwapped Value of a={}".format(a))
print("\tSwapped Value of b={}".format(b))
print("-"*50)


#program for Cal Square Root of a Given Number--sqrt() of math module
#ArithmeticOpEx2.py
import math
n=float(input("Enter Value of n: "))
sqrtv=math.sqrt(n)
print("Sqrt({})={}".format(n,sqrtv))
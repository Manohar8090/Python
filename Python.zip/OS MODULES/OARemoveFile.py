#progfram for Removing a File
#OARemoveFile.py
import os
try:
    os.remove("D:\\PACK2\\mi.py")
    print("File Name removed--verify")
except FileNotFoundError:
    print("File not found--verify")


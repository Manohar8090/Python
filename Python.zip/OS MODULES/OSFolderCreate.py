#Program for Creating a Folder----we use mkdir()
#OSFolderCreate.py
import os
try:
    os.mkdir("INDIA")
    print("Folder Created--verify")
except FileExistsError:
    print("Folder already exists")
except FileNotFoundError:
    print("Root Folder doesn't exist")
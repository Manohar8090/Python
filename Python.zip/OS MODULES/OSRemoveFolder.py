#Program for Removing the folder
#OSRemoveFolder.py
import os
try:
    os.rmdir("C:\\KVR")
    print("Folder Removed")
except FileNotFoundError:
    print("Folder Not Found")
except OSError:
    print("Folder Must empty-enure it")
#program for Listing the Files in Folder
#OSListFiles.py
import os
FilesList=os.listdir("E:\\KVR-PYTHON-11AM\\FILES")
print("Number of Files=",len(FilesList))
for FileName in FilesList:
    print("\t{}".format(FileName))
#Program for Renaming a Folder
#OSRenameFolder.py
import os
try:
    os.rename("INDIA","BHARAT")
    print("Folder renamed--verify")
except FileNotFoundError:
    print("Source Folder Does Not Found")
#Program for Getting Currently Executing Thread
#CurrentThreadEx.py
import threading
t=threading.current_thread()
print("Currently Executing Thread=",t.name)
print("---------------------------OR-----------------------------")
print("Currently Executing Thread=",threading.current_thread().name)
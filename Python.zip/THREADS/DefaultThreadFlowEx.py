#Program for Showing Internal Flow of Default thread
#DefaultThreadFlowEx.py
import threading
def  welcome():
	print("\t{}-->welcome()".format(threading.current_thread().name))
def  hello():
	print("\t{}-->hello()".format(threading.current_thread().name))
def  hi():
	print("\t{}-->hi()".format(threading.current_thread().name))

#Main Program
print("Program Execution Started:{}".format(threading.current_thread().name))
welcome()
hello()
hi()
print("Program Execution Stoped:{}".format(threading.current_thread().name))
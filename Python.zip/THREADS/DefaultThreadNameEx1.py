#Program for Getting the Default Thread name
#DefaultThreadNameEx1.py
import threading
tname=threading.current_thread().name
print("Default Thread Name=",tname)
print("Number of Threads by default exist=",threading.active_count())
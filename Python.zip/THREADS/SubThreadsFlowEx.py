#Program for Showing Internal Flow of Sub Threads with Default thread
#SubThreadsFlowEx.py
import threading
def  welcome():
	print("\t{}-->welcome()".format(threading.current_thread().name))
def  hello():
	print("\t{}-->hello()".format(threading.current_thread().name))
def  hi():
	print("\t{}-->hi()".format(threading.current_thread().name))

#Main Program---
print("Program Execution Started:{}".format(threading.current_thread().name))
#Create 3 Sub Threads
t1=threading.Thread(target=welcome) # here t1 is sub thread object whose default name is 'thread-1'
t2=threading.Thread(target=hello) # here t2 is sub thread object whose default name is 'thread-2'
t3=threading.Thread(target=hi) # here t3 is sub thread object whose default name is 'thread-3'
#dispatch the sub threads
t1.start()
t2.start()
t3.start()
t1.join()
t2.join()
t3.join()
print("Program Execution Stoped:{}".format(threading.current_thread().name))
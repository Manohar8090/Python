#Program for Showing Dead lock Elimination
#DeadLockOopsFunEx3.py
import threading,time
class MulTable:
	#Create an Object of Lock Class
	L=threading.Lock()  #Step-1 --here L is Called Class Level Data Member
	def __init__(self,n):
		self.n=n
	def table(self):
		#Get the Lock on Function--Step-2
		MulTable.L.acquire() 
		if(self.n<=0):
			print("\t{}---> {} Invalid input".format(threading.current_thread().name,self.n))
		else:
			print("Mul table for {}".format(self.n))
			for i in range(1,11):
				print("\t{}--->{} x {} = {}".format(threading.current_thread().name,self.n,i,self.n*i))
				time.sleep(0.00025)
		#Release the Lock-Step-3
		MulTable.L.release()
		print("----------------------------------------------------------------------")
#Main Program

#Create Multiple Threads
t1=threading.Thread(target=MulTable(19).table)
t2=threading.Thread(target=MulTable(17).table)
t3=threading.Thread(target=MulTable(-8).table)
t4=threading.Thread(target=MulTable(9).table)
#Dispatch the sub threads
t1.start()
t2.start()
t3.start()
t4.start()

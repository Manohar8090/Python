#Program for Getting actively Running Threads by Default
#ActiveThreadsEx.py
import threading
noat=threading.active_count()
print("Default Name of Thread=",threading.current_thread().name)
print("By Default, Number of Active Threads=",noat)
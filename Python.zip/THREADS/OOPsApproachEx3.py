#Program for Showing Internal Flow of Sub Threads with Default thread
#OOPsApproachEx3.py
import threading # Step-1
class Sample1:    # Step-2
	def  welcome(self):   # Step-3
		print("\t{}-->welcome()".format(threading.current_thread().name))
class Sample2:
	def  hello(self):
		print("\t{}-->hello()".format(threading.current_thread().name))
class Sample3:	
	def  hi(self):
		print("\t{}-->hi()".format(threading.current_thread().name))

#Main Program---
print("Program Execution Started:{}".format(threading.current_thread().name))
#Create 3 Sub Threads--Step-4
t1=threading.Thread(target=Sample1().welcome) # here t1 is sub thread object whose default name is 'thread-1'
t2=threading.Thread(target=Sample2().hello) # here t2 is sub thread object whose default name is 'thread-2'
t3=threading.Thread(target=Sample3().hi) # here t3 is sub thread object whose default name is 'thread-3'
#dispatch the sub threads--Step-4
t1.start()
t2.start()
t3.start()
t1.join()
t2.join()
t3.join()
print("Program Execution Stoped:{}".format(threading.current_thread().name))
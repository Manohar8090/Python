#Program for Demonstrating  join() and Sub Threads
#JoinMethodEx.py
import threading,time
def welcome(Value):
	print("\tHi {}, Wel Come to Multi Threading".format(Value))
	time.sleep(5)
	print("\t{} is Coming-out-off Sleep after 5 Seconds".format(threading.current_thread().name))

#main program
print("Program Execution Started:{}".format(threading.current_thread().name))
t1=threading.Thread(target=welcome,args=("Rossum",) )
print("Execution Status of t1 before start()=",t1.is_alive())
t1.start()
print("Execution Status of t1 after start()=",t1.is_alive())
#Make the Main Thread to wait until sub threads Join
t1.join()
print("Execution Status of t1 after join()=",t1.is_alive())
print("Program Execution Ended:{}".format(threading.current_thread().name))
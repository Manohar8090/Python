#Program for Setting the Thread Name and Getting the Thread Name
#SetGetMethodEx.py
import threading
def welcome(Value):
	print("Hi {}, Wel Come to Multi Threading".format(Value))

#main program
print("Program Execution Started: Name of Thread:",threading.current_thread().name)
t1=threading.Thread(target=welcome,args=("Rossum",) ) # Here t1 is called Sub Thread and whose Name is Thread-1
#tname=t1.getName()---Not Recommended to Use
tname=t1.name
print("Default Sub Thread Name before setting=",tname)#
#t1.setName("KVR")------Not Recommended to Use
t1.name="KVR"
tname=t1.name
print("Sub Thread Name after setting=",tname)#
t1.start()
print("Program Execution Ended: Name of Thread:",threading.current_thread().name)
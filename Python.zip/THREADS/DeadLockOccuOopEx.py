#Program for Showing Dead lock Occurence
#DeadLockOccuOopEx.py
import threading,time
class MulTable:
	def table(self,n):
		if(n<=0):
			print("\t{}---> {} Invalid input".format(threading.current_thread().name,n))
		else:
			print("Mul table for {}".format(n))
			for i in range(1,11):
				print("\t{}--->{} x {} = {}".format(threading.current_thread().name,n,i,n*i))
				time.sleep(1)
			print("----------------------------------------------------------------------")
#Main Program
t1=threading.Thread(target=MulTable().table,args=(19,))
t2=threading.Thread(target=MulTable().table,args=(17,))
t3=threading.Thread(target=MulTable().table,args=(-8,))
t4=threading.Thread(target=MulTable().table,args=(9,))
#Dispatch the sub threads
t1.start()
t2.start()
t3.start()
t4.start()

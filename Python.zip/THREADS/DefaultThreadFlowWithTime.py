#Program for Showing the Internal flow of Default Thread with Time
#DefaultThreadFlowWithTime.py
import threading,time
def  square(lst):
	for val in lst:
		print("\t{}--->square({})={}".format(threading.current_thread().name,val,val**2))
		time.sleep(1)
def  cubes(lst):
	for val in lst:
		print("\t{}--->cube({})={}".format(threading.current_thread().name,val,val**3))
		time.sleep(1)
#Main Program
bt=time.time()
print("Program Execution Started:{}".format(threading.current_thread().name))
lst=[10,13,5,9,-12,19,25,18,23,6,15]
square(lst)
print("------------------------------------------------------------")
cubes(lst)
print("Program Execution Stoped:{}".format(threading.current_thread().name))
et=time.time()
print("Total Execution Time by Single Default Thread=",(et-bt))
#Program for Showing Dead lock Elimination
#DeadLockEliminationFunEx.py
import threading,time
def table(n):
	#Get the Lock on Function--Step-2
	L.acquire() 
	if(n<=0):
		print("\t{}---> {} Invalid input".format(threading.current_thread().name,n))
	else:
		print("Mul table for {}".format(n))
		for i in range(1,11):
			print("\t{}--->{} x {} = {}".format(threading.current_thread().name,n,i,n*i))
			time.sleep(0.00000000000000000000001)
	#Release the Lock-Step-3
	L.release()
	print("----------------------------------------------------------------------")
#Main Program
#Create an Object of Lock Class
L=threading.Lock()  #Step-1
#Create Multiple Threads
t1=threading.Thread(target=table,args=(19,))
t2=threading.Thread(target=table,args=(17,))
t3=threading.Thread(target=table,args=(-8,))
t4=threading.Thread(target=table,args=(9,))
#Dispatch the sub threads
t1.start()
t2.start()
t3.start()
t4.start()

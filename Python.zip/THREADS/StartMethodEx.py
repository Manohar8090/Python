#Program for Demonstrating start() and Sub Threads
#StartMethodEx.py
import threading
def welcome(Value):
	print("Hi {}, Wel Come to Multi Threading".format(Value))

#main program
t1=threading.Thread(target=welcome,args=("Rossum",) )
t1.start()
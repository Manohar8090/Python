#Program for Reseving a Ticket
#TrainRerservationOOpsEx1.py
import threading,time
class Train:
	K=threading.Lock() # Here K is Lock object and It is Class Level data Member
	def reserve(self,pseats):
		Train.K.acquire()
		global totseats
		if(pseats>totseats):
			print("\tHi '{}' Passenger, {} Seats are not Available-try next".format(threading.current_thread().name,pseats))
			time.sleep(2)
		else:
				totseats=totseats-pseats
				print("\tHi '{}' Passenger, {} Seats are Reserved-Hpy Jrny".format(threading.current_thread().name,pseats))
				time.sleep(1)
				print("\tNOW AVAILABLE SEATS=",totseats)
				time.sleep(2)
				if(totseats==0):
					print("\tTRAIN IS FULL")
		Train.K.release()

#main program
totseats=12
#Create Multiple Threads (Passengers)
p1=threading.Thread(target=Train().reserve,args=(4,))
p1.name="Richikesh"
p2=threading.Thread(target=Train().reserve,args=(6,))
p2.name="saqeeb"
p3=threading.Thread(target=Train().reserve,args=(5,))
p3.name="praveen"
p4=threading.Thread(target=Train().reserve,args=(2,))
p4.name="Kvr"
p5=threading.Thread(target=Train().reserve,args=(1,))
p5.name="Himanshu"
#dispatch the threads
p1.start()
p2.start()
p3.start()
p4.start()
p5.start()

#Program for Demonstrating is_alive() and Sub Threads
#IsAliveEx.py
import threading
def welcome(Value):
	print("Hi {}, Wel Come to Multi Threading".format(Value))

#main program
t1=threading.Thread(target=welcome,args=("Rossum",) )
print("Execution Status of Sub thread t1 before start()=",t1.is_alive()) #False
t1.start()
print("Execution Status of Sub thread t1 after start()=",t1.is_alive()) #True
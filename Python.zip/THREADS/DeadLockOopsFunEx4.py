#Program for Showing Dead lock Elimination
#DeadLockOopsFunEx4.py
import threading,time
class MulTable:
	#Create an Object of Lock Class
	L=threading.Lock()  #Step-1 --here L is Called Class Level Data Member
	def __init__(self,n):
		self.n=n
	def table(self):
		#Get the Lock on Function--Step-2
		MulTable.L.acquire() 
		if(self.n<=0):
			print("\t{}---> {} Invalid input".format(threading.current_thread().name,self.n))
		else:
			print("Mul table for {}".format(self.n))
			for i in range(1,11):
				print("\t{}--->{} x {} = {}".format(threading.current_thread().name,self.n,i,self.n*i))
				time.sleep(0.00025)
		#Release the Lock-Step-3
		MulTable.L.release()
		print("----------------------------------------------------------------------")
#Main Program

#Create Multiple Threads
threading.Thread(target=MulTable(19).table).start()
threading.Thread(target=MulTable(17).table).start()
threading.Thread(target=MulTable(-8).table).start()
threading.Thread(target=MulTable(9).table).start()

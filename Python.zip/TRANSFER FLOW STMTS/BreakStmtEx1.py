#BreakStmtEx1.py
s="PYTHON"
print("By Using For Loop")
for ch in s:
    print("\t{}".format(ch))
else:
    print("I am from else part of for loop")
print("--------------------------------------")
#Today My Req: To disp: PYTH  without using Indexing and Slicing Operations
for ch in s:  # s="PYTHON"
    if(ch=="O"):
        break
    print(ch,end="")
else:
    print("I am from else part of for loop")
print()
print("--------------------------------------")


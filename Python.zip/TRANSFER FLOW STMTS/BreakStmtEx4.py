#BreakStmtEx4.py
s="MISSISSIPPI"
print("By Using while Loop")
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
else:
    print("I am from else part of while loop")
print("--------------------------------------")
#Today My Req: To disp: MISS without using Indexing and Slicing Operations
ctr=0
i=0
while(i<len(s)): # s="MISSISSIPPI"
    if(s[i]=="I"):
        ctr=ctr+1
        if(ctr==2):
            break
    print(s[i],end="")
    i=i+1
else:
    print("I am from else part of while loop")
print()
print("--------------------------------------")


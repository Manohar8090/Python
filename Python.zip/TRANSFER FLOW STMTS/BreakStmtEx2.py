#BreakStmtEx2.py
s="PYTHON"
print("By Using while Loop")
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
else:
    print("I am from else part of while loop")
print("--------------------------------------")
#Today My Req: To disp: PYTH  without using Indexing and Slicing Operations
i=0
while(i<len(s)):  # s="PYTHON"
    if(s[i]=="O"):
        break
    print(s[i],end="")
    i=i+1
else:
    print("I am from else part of while loop")
print()
print("--------------------------------------")


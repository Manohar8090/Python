#Program for Obtaining List of -VE Values  from List of Values
#ContinueStmtEx6.py
lst=[10,-20,-30,40,50,-15,13,-24,56,0,-34]
nslist=[]
for val in lst:
    if(val>=0):
        continue
    nslist.append(val)
else:
    print("List of -VE Values")
    print(nslist)
#program for accepting a Word and decide whether It is Vowel Word or not
#BreakStmtEx7.py
word=input("Enter a word: ")
i=0
decision="Not Vowel Word"
while(i<len(word)):
    if(word[i].lower()) in list("aeiou"):
        decision="Vowel Word"
        break
    i=i+1
print("{} is {}".format(word,decision))


#program for accepting a Number and decide whether It is Prime or not
#BreakStmtEx6.py
n=int(input("Enter a number: "))
if(n<=1):
    print("\t{} is Invalid input".format(n))
else:
    res=True
    for i in range(2,n):
        if(n%i==0):
            res=False
            break
    print("\t{} is {}".format(n,"PRIME" if res else "NOT PRIME"))
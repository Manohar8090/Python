#program for accepting a Number and decide whether It is Prime or not
#BreakStmtEx5.py
n=int(input("Enter a number: "))
if(n<=1):
    print("\t{} is Invalid input".format(n))
else:
    res="PRIME"
    for i in range(2,n):
        if(n%i==0):
            res="NOT PRIME"
            break
    print("{} is {}".format(n,res))





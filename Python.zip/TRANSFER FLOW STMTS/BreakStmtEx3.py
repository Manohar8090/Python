#BreakStmtEx3.py
s="MISSISSIPPI"
print("By Using For Loop")
for ch in s:
    print("\t{}".format(ch))
else:
    print("I am from else part of for loop")
print("--------------------------------------")
#Today My Req: To disp: MISS without using Indexing and Slicing Operations
ctr=0
for ch in s: # s="MISSISSIPPI"
    if(ch=="I"):
        ctr=ctr+1
        if(ctr==2):
            break
    print(ch,end="")
else:
    print("I am from else part of for loop")
print()
print("--------------------------------------")


#program for Reading List of old Salaries and Give 50% Hike to Every Employee
#MapEx3.py
print("Enter List of Old Salaries Separated Comma:")
oldsal=[float(sal) for sal in input().split(",")]
#Give 50% Hike
newsal=list(map(lambda salary:salary*1.5,oldsal)) # here kvr is an object <class,map>
print("-"*50)
print("Old Salary\t\tNew Salary")
print("-"*50)
for ol,nl in zip(oldsal,newsal):
    print("\t{}\t\t{}".format(ol,nl))
print("-"*50)


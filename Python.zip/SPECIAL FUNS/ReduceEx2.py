#program for computing sum of list of Eelemnts
#ReduceEx2.py
import functools
sumop=lambda k,v:k+v
#Main Program
print("Enter List of values separated by Comma:")
lst=[float(val) for val in input().split(",")]
res=functools.reduce(sumop,lst)
print("sum=",res)



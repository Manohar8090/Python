#program for accepting List of Values from KBD and Filter Only +E Values
#FilterEx1.py
def pos(value):
    if value>0:
        return True
    else:
        return False

#Main Program
print("Enter list of Values Separated by Comma:")
lst=[float(val) for val in input().split(",")] # list Comprehension
print("Given List of Elements ")
print(lst) # [10,23,-45,-46,12,-67,0,89]
kvr=filter(pos, lst) # here kvr is an object of <class, filter>
#Convert filter object into list type
pslist=list(kvr)
print("List of +VE Elements=",pslist)
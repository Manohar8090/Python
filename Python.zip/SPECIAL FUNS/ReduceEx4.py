#program for Max Element from list of Eelemnts
#ReduceEx4.py
import functools
def kvrmax(a,b):
    return a if a>b else b
def kvrmin(a,b):
    return a if a<b else b

#main Program
print("Enter List of values separated by Comma:")
lst=[float(val) for val in input().split(",")]
print("Given List of Eleemnts:",lst)
maxval=functools.reduce(kvrmax,lst)
minval=functools.reduce(kvrmin,lst)
print("Max Value=",maxval)
print("Min Value=",minval)

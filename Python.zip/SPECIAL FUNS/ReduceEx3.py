#program for computing sum of list of Eelemnts
#ReduceEx3.py
import functools
print("Enter List of values separated by Comma:")
lst=[float(val) for val in input().split(",")]
res=functools.reduce(lambda k,v:k+v , lst)
print("sum=",res)
#program for accepting List of Values from KBD and Filter Only +E Values
#FilterEx4.py
print("Enter list of Values Separated by Comma:")
lst=[float(val) for val in input().split(",")] # list Comprehension
print("Given List of Elements ")
print(lst) # [10,23,-45,-46,12,-67,0,89]
pslist=list(filter(lambda val:val>0, lst))
nglist=tuple(filter(lambda val:val<0, lst))
print("List of +VE Elements=",pslist)
print("List of -VE Elements=",nglist)
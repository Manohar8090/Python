#program for Obtaining List of Words whose length ranges between 3 to 4
#FilterEx5.py
print("Enter List of words Separated by Comma:")
words=[word for word in input().split(",")]
print("Given words")
print(words)
words34=list(filter(lambda word:len(word) in range(3,5), words))
print("List of words whose length between 3 to 4")
print(words34)

#program for Max Element from list of Eelemnts
#ReduceEx5.py
import functools
print("Enter List of values separated by Comma:")
lst=[float(val) for val in input().split(",")]
print("Given List of Eleemnts:",lst)
maxval=functools.reduce(lambda a,b: a if a>b else b,lst)
minval=functools.reduce(lambda a,b: a if a<b else b,lst)
print("Max Value=",maxval)
print("Min Value=",minval)

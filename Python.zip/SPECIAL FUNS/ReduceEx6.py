#program for Max Element from list of Eelemnts
#ReduceEx5.py
import functools
print("Enter List of Words separated by Comma:")
words=[val for val in input().split(",")]
print("Given Words")
print(words)
line=functools.reduce(lambda word1,word2: word1+" "+word2, words)
print("Given Line of Text")
print(line)

#program accepting List of values in two list objects and add tehm
#MapEx4.py
print("Enter list of Values for First List separated by comma")
lst1=[float(val) for val in input().split(",")]
print("Enter list of Values for Second List separated by comma")
lst2=[float(val) for val in input().split(",")]
lst3=list(map(lambda k,v: k+v,  lst1,lst2))
print("List1\t\tList2\t\tList3")
print("-"*50)
for k,v,r in zip(lst1,lst2,lst3):
    print("\t{}\t\t{}\t\t\t{}".format(k,v,r))
print("-"*50)

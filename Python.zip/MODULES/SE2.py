#SE2.py<------program name
import Aop
Aop.sumop(10,20)
Aop.subop(30,40)
Aop.mulop(4,5)
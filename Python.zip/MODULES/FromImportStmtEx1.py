#FromImportStmtEx1.py
from MathsInfo import PI,E
from Aop import sumop,subop,mulop
from icici import bname,addr,simpleint
print("-----------------------------------------")
print("Val of PI=",PI)
print("Val of E=",E)
print("-----------------------------------------")
sumop(10,20)
subop(30,40)
mulop(4,5)
print("-----------------------------------------")
print(bname)
print(addr)
simpleint()
print("-----------------------------------------")

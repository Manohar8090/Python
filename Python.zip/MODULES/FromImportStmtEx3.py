#FromImportStmtEx3.py
from Aop import *
from MathsInfo import *
from icici import *
print("-----------------------------------------")
print("Val of PI=",PI)
print("Val of E=",E)
print("Val of bname=",bname)
print("-----------------------------------------")
sumop(10,20)
subop(30,40)
mulop(4,5)
print("-----------------------------------------")
print(bname)
print(addr)
simpleint()
print("-----------------------------------------")

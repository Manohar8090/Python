#ImportStmtSyntax2.py
import MathsInfo,Aop,icici
print("-----------------------------------------")
print("Val of PI=",MathsInfo.PI)
print("Val of E=",MathsInfo.E)
print("-----------------------------------------")
Aop.sumop(10,20)
Aop.subop(30,40)
Aop.mulop(4,5)
print("-----------------------------------------")
print(icici.bname)
print(icici.addr)
icici.simpleint()
print("-----------------------------------------")

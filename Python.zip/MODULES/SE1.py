#SE1.py<----I will come back--Program name
import MathsInfo
print("Val of PI=",MathsInfo.PI)
print("Val of E=",MathsInfo.E)
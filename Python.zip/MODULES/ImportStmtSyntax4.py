#ImportStmtSyntax2.py
import MathsInfo as mi, Aop as ap,icici as ic
print("-----------------------------------------")
print("Val of PI=",mi.PI)
print("Val of E=",mi.E)
print("-----------------------------------------")
ap.sumop(10,20)
ap.subop(30,40)
ap.mulop(4,5)
print("-----------------------------------------")
print(ic.bname)
print(ic.addr)
ic.simpleint()
print("-----------------------------------------")

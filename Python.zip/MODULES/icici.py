#icici.py<----File Name<---Module Name
bname="ICICI"
addr="AMPT-HYD" # here bname,addr are called Global Variables
def simpleint(): # Function def
    p = float(input("Enter Principle Amount:"))
    t = float(input("Enter Time:"))
    r = float(input("Enter rate of Interest:"))
    si = (p * t * r) / 100
    totamt = p + si
    print("\tSimple Interest Calculations")
    print("-" * 50)
    print("\t\tPrinciple Amount:{}".format(p))
    print("\t\tTime:{}".format(t))
    print("\t\tRate of Interest:{}".format(r))
    print("\t\tSIMPLE INTEREST:{}".format(si))
    print("\t\tTOTAL AMOUNT TO PAY:{}".format(totamt))
    print("-" * 50)


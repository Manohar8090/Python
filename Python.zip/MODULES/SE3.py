#SE3.py<---Program name
import icici
import calendar
print(icici.bname)
print(icici.addr)
icici.simpleint()
print("---------------------------------")
print(calendar.month(2025,9))

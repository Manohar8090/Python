#FromImportStmtEx2.py
from Aop import sumop as ap,subop as sp,mulop as mp
from icici import bname as bn,addr as ad,simpleint as si
from MathsInfo import PI as p,E,bname as mb
print("-----------------------------------------")
print("Val of PI=",p)
print("Val of E=",E)
print("Val of bname=",mb)
print("-----------------------------------------")
ap(10,20)
sp(30,40)
mp(4,5)
print("-----------------------------------------")
print(bn)
print(ad)
si()
print("-----------------------------------------")

#ImportStmtSyntax3.py
import MathsInfo as mi
import Aop as ap
import icici as ic
print("-----------------------------------------")
print("Val of PI=",mi.PI)
print("Val of E=",mi.E)
print("-----------------------------------------")
ap.sumop(10,20)
ap.subop(30,40)
ap.mulop(4,5)
print("-----------------------------------------")
print(ic.bname)
print(ic.addr)
ic.simpleint()
print("-----------------------------------------")

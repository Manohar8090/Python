#Program for Extracting the Names of the People from given Text
#NamesExtractEx.py
import re
gd="Rossum is the author of python, Ritche is author of c , Gosling is the author of java, Travis is the author of numpy and Kinney is the author pandas"
sp="[A-Z][a-z]+"
nameslist=re.findall(sp,gd)
print("List of Names")
for names in nameslist:
	print("\t{}".format(names))


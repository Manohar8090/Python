#Program for Searching a Word in Given Data
#RegExprEx2.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
sp="Python"
mat=re.search(sp,gd) # here mat is of  type  <class, re.match> OR <class, NoneType>
if(mat!=None):
	print("Search is SucessFul")
	print("Type of mat=",type(mat))
	print("Matched Values=",mat.group())#Python
	print("Starting Index=",mat.start()) # 0
	print("Ending Index=",mat.end()) # 6
else:
	print("Search is Un-SucessFul")
	print("Type of mat=",type(mat))
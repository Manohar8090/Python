#Program for Searching a Word in Given Data
#RegExprEx3.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
sp="Python"
print("-"*50)
matdet=re.finditer(sp,gd) # here mat is of  type  <class, callable_iterator>
for mat in matdet: # here mat is an object of <class, re.match>
	print("Start Index: {}   End Index:{}  value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)	

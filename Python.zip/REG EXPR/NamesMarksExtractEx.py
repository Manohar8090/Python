#Program for Extracting the Name and Marks of the People from given Text
#NamesMarksExtractEx.py
import re
gd="Rossum got 55 marks, Ritche got 33 marks , Gosling got 24 marks, Travis got 78 marks and Kinney got 46 marks"
sp1=r"\d+"
sp2="[A-Z][a-z]+"
markslist=re.findall(sp1,gd)
nameslist=re.findall(sp2,gd)
print("-"*50)
print("\tNames\tMarks")
print("-"*50)
for names,marks in zip(nameslist,markslist):
	print("\t{}\t{}".format(names,marks))
print("-"*50)
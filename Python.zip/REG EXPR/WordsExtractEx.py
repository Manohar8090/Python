#Program for Extracting the words of the People from given Text
#WordsExtractEx.py
import re
gd="Rossum is the author of python, Ritche is author of c , Gosling is the author of java, Travis is the author of numpy and Kinney is the author pandas"
sp=r"[A-Za-z]+"
matdet=re.findall(sp,gd)
print("-"*50)
for mat in matdet:
	print("Value: {}".format(mat))
print("-"*50)

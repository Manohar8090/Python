#Program for  Validating the Mobile Number
#MobileNumberValidEx.py
import re
while(True):
	mno=input("Enter Ur Mobile Number:")
	if(len(mno)==10):
		res=re.search(r"\d{10}",mno)
		if(res!=None):
			print("\t{} is Valid Mobile Number".format(mno))
			break
		else:
			print("\t{} is Invalid Mobile Number--Must enter int digits Only-try again".format(mno))
	else:
		print("\t {} is Invalid Mobile Number of Length--try again".format(mno))
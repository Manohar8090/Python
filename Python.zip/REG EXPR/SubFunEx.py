#Program for Demonstrating sub() of re module
#SubFunEx.py
import re
gd="PYTHON"
s=re.sub("P","J",gd)
print(s)
print("------------------------------------------------")
gd="MISSISSIPPI"
s=re.sub("I","H",gd)
print(s)
print("------------------------------------------------")
gd="Teacher is explaining  and student is sleeping"
s=re.sub(r"\s","->",gd)
print(s)
s1=re.sub("->","<-",s)
print(s1)
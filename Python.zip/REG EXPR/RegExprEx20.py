#Proghram for Searching all Space Chars
#RegExprEx20.py
import re
gd="Ak5 r9PbM@v7 GQs4Ts6#Ln8Df"
sp=r"\s"
matdet=re.finditer(sp,gd)
print("-"*50)
for mat in matdet:
	print("Start Index:{}   End Index:{}   Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)
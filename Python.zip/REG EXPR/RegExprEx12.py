#Proghram for Searching all Alphabets
#RegExprEx12.py
import re
gd="Ak5r9PbM@v7GQs4Ts6#Ln8Df"
sp="[A-Za-z]"
matdet=re.finditer(sp,gd)
print("-"*50)
for mat in matdet:
	print("Start Index:{}   End Index:{}   Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)
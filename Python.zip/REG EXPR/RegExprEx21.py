#Proghram for Searching all  except Space Chars
#RegExprEx21.py
import re
gd="Ak5 r9PbM@v7 GQs4Ts6#Ln8Df"
sp=r"\S"
matdet=re.finditer(sp,gd)
print("-"*50)
for mat in matdet:
	print("Start Index:{}   End Index:{}   Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)
#Program for Extracting the Marksof the People from given Text
#MarksExtractEx.py
import re
gd="Rossum got 55 marks, Ritche got 33 marks , Gosling got 24 marks, Travis got 78 marks and Kinney got 46 marks"
sp=r"\d+"
markslist=re.findall(sp,gd)
print("Marks of Students")
for marks in markslist:
	print("\t{}".format(marks))

#Program for Extracting the Name and Marks of the People from  Text is available in File(students.data)
#NamesMarksExtractFromFilesEx.py
import re
try:
	with open("E:\\KVR-PYTHON-11AM\\REG EXPR\\NOTES\\students.data","r") as fp:	
		filedata=fp.read()
		sp1=r"\d+"
		sp2="[A-Z][a-z]+"
		markslist=re.findall(sp1,filedata)
		nameslist=re.findall(sp2,filedata)
		print("-"*50)
		print("\tNames\tMarks")
		print("-"*50)
		for names,marks in zip(nameslist,markslist):
			print("\t{}\t{}".format(names,marks))
		print("-"*50)
except FileNotFoundError:
	print("File Does Not Exist")
#Program for Extracting the Name and Mails of the People from  Text is available in File(mails.data)
#NamesMailsExtractFromFilesEx.py
import re
try:
	with open("E:\\KVR-PYTHON-11AM\\REG EXPR\\NOTES\\mails.data","r") as fp:	
		filedata=fp.read()
		sp1="[A-Z][a-z]+"
		sp2=r"\S+@\S+"
		nameslist=re.findall(sp1,filedata)
		mailslist=re.findall(sp2,filedata)
		print("-"*50)
		print("\tNames\t\tMail-Id")
		print("-"*50)
		for names,mails in zip(nameslist,mailslist):
			print("\t{}\t\t{}".format(names,mails))
		print("-"*50)
except FileNotFoundError:
	print("File Does Not Exist")
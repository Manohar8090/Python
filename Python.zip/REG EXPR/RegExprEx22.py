#Program for Searching exactly One K
#RegExprEx22.py
import re
gd="KVKKVKKKVKV"
sp="K"
matdet=re.finditer(sp,gd)
print("-"*50)
for mat in matdet:
	print("Start Index:{}  End Index: {}  Value: {}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)

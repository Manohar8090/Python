#Program for Searching a Word in Given Data
#RegExprEx1.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
sp="Python"
noa=re.findall(sp,gd)
if(len(noa)!=0):
	print("\tSearch is SucessFul")
	print("\t'{}' Found {} Times".format(sp,len(noa)))
else:
		print("\tSearch is Un-SucessFul")
		print("\t'{}' Found {} Times".format(sp,len(noa)))

#Program for Reading Student details from KBD
#and insert them as Record in File by using Classes and Objects with pickling
#OOPsWithPickEx.py
import pickle
from Student import Student
class StudentPick:
    def savestuddata(self):
        with open("E:\\KVR-PYTHON-11AM\\OOPS\\student.data", "ab") as fp:
            #Accept the Student from KBD
            print("--------------------------------")
            sno=int(input("Enter student no."))
            sname=input("Enter student name.")
            marks=float(input("Enter student marks."))
            print("--------------------------------")
            #add the above values to student object
            so=Student()
            so.getstuddata(sno,sname,marks)
            #save student object data into the file
            pickle.dump(so,fp)
            print("Student Record Saved in File")
            print("--------------------------------")


#main program
sp=StudentPick()
sp.savestuddata()




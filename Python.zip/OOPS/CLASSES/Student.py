#Student.py<---Module Name
class Student:
    def getstuddata(self,sno,sname,marks):
        self.sno=sno
        self.sname=sname
        self.marks=marks
    def dispstudvals(self):
        print("\t{}\t{}\t{}".format(self.sno,self.sname,self.marks))

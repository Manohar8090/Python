#Program for Demonstrating the Instance Method
#InstanceMethodEx2.py
class Student:
    def getstuddata(self,objinfo):
        print("Enter {} Object Information:".format(objinfo))
        self.sno=int(input("\tEnter Student Number:"))
        self.name=input("\tEnter Student Name:")
        self.marks=float(input("\tEnter Student Marks:"))
    def dispstuddata(self,objinfo):
        print("{} Object Information:".format(objinfo))
        print("\tStudent Number=",self.sno)
        print("\tStudent Name=",self.name)
        print("\tStudent Marks=",self.marks)

#main program
s1=Student()
s2=Student()
print("----------------------------------------")
s1.getstuddata("First")
print("----------------------------------------")
s2.getstuddata("Second")
print("----------------------------------------")
s1.dispstuddata("First")
print("----------------------------------------")
s2.dispstuddata("Second")
print("----------------------------------------")


#Program for Demonstrating the Class Level Method
#ClassLevelMethodEx1.py
class Student:
    @classmethod
    def getcrs(cls):
        cls.crs="PYTHON" #OR Student.crs="PYTHON
        cls.city="HYD" # OR Student.city="HYD

#Main Program
Student.getcrs() # calling Class Method
s=Student()
print("Content of s object=",s.__dict__)
print("Student Course=",Student.crs)
print("Student City=",Student.city)
print("-----------------OR------------------")
print("Student Course=",s.crs)
print("Student City=",s.city)

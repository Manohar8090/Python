#Program for Reading Employee Values from KBD and Insert them as
# Record in Employee Table--MySQL
#OOPsWithDataBaseEx1.py
import mysql.connector as mc
class Employee:
    def getempdetails(self):
        self.empno=int(input("Enter the employee number: "))
        self.name=input("Enter the employee name: ")
        self.salary=float(input("Enter the employee salary: "))
        self.cname = input("Enter the employee comp name: ")
    def saveemployeedata(self):
        try:
            con=mc.connect(host="localhost",
                        user="root",
                        passwd="root",
                        use_pure=True,
                        database="batch11am")
            cur=con.cursor()
            iq="insert into employee values(%d,'%s',%f,'%s')" %(self.empno,self.name,self.salary,self.cname)
            cur.execute(iq)
            con.commit()
            print("{} Record Inserted".format(cur.rowcount))
        except mc.DatabaseError as db:
            print("Problem in MySQL:",db)

#Main Program
eo=Employee()
eo.getempdetails()
eo.saveemployeedata()


#Program for storing sno,sname and Marks of Multiple students
#InstanceDataMemberEx3.py
class Student:pass

#Main Program
#Create Two objects of Student
s1=Student()
s2=Student()
print("---------------------------------------")
#Place the Data in S1--Instance Data Members
s1.sno=int(input("Enter First Student Number:"))
s1.name=input("Enter First Student Name:")
s1.marks=float(input("Enter First Student Marks:")) # here sno,name,marks are called Instance Data members
print("---------------------------------------")
#Place the Data in S2--Instance Data Members
s2.sno=int(input("Enter Second Student Number:"))
s2.name=input("Enter Second Student Name:")
s2.marks=float(input("Enter Second Student Marks:")) # here sno,name,marks are called Instance Data members
#Display the Content of s1 object
print("First Student Data")
print("\tStudent Number=",s1.sno)
print("\tStudent Name=",s1.name)
print("\tStudent Marks=",s1.marks)
print("---------------------------------------")
#Display the Content of s1 object
print("Second Student Data")
print("\tStudent Number=",s2.sno)
print("\tStudent Name=",s2.name)
print("\tStudent Marks=",s2.marks)
print("---------------------------------------")
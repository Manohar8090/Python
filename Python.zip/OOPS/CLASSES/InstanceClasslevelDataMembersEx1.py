#Program for storing sno,sname Marks and crs  of Multiple students
#InstanceClasslevelDataMembersEx1.py
class Student:
    crs="PYTHON"  # here crs is Called Class Level Data Member

#Main Program
#Create Two objects of Student
s1=Student()
s2=Student()
print("---------------------------------------")
#Place the Data in S1--Instance Data Members
s1.sno=100
s1.name="Rossum"
s1.marks=34.56 # here sno,name,marks are called Instance Data members
#Place the Data in S2--Instance Data Members
s2.sno=200
s2.name="Hunter"
s2.marks=64.56 # here sno,name,marks are called Instance Data members
#Display the Content of s1 object
print("First Student Data")
print("\tStudent Number=",s1.sno)
print("\tStudent Name=",s1.name)
print("\tStudent Marks=",s1.marks)
print("\tStudent COURSE=",Student.crs)
print("---------------------------------------")
#Display the Content of s1 object
print("Second Student Data")
print("\tStudent Number=",s2.sno)
print("\tStudent Name=",s2.name)
print("\tStudent Marks=",s2.marks)
print("\tStudent COURSE=",Student.crs)
print("---------------------------------------")
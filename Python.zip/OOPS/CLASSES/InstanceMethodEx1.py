#Program for Demonstrating the Instance Method
#InstanceMethodEx1.py
class Student:
    def getstuddata(self):
        print("Ref / Addr of Current object=",id(self))

#main program
s1=Student()
s2=Student()
print("----------------------------------------")
print("ID of s1 in main program=",id(s1))
s1.getstuddata()
print("----------------------------------------")
print("ID of s2 in main program=",id(s2))
s2.getstuddata()
print("----------------------------------------")

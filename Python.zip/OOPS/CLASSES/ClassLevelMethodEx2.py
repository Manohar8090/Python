#Program for Demonstrating the Class Level Method
#ClassLevelMethodEx1.py
class Student:
    @classmethod
    def getcrs(cls):
        cls.crs="PYTHON" #OR Student.crs="PYTHON
        cls.getcity() # OR Student.getcity() --->Calling Class Level method of same class
    @classmethod
    def getcity(cls):
        cls.city="HYD" # OR Student.city="HYD

#Main Program
Student.getcrs() # calling Class Method
s=Student()
print("Student Course=",Student.crs)
print("Student City=",Student.city)
print("-----------------OR------------------")
print("Student Course=",s.crs)
print("Student City=",s.city)

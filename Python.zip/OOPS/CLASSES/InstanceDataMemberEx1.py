#Program for storing sno,sname and Marks of Multiple students
#InstanceDataMemberEx1.py
class Student:pass

#Main Program
print("---------------------------------------")
#Create Two objects of Student
s1=Student()
s2=Student()
print("ID of s1=",id(s1))
print("ID of s2=",id(s2))
print("---------------------------------------")
#Place the Data in S1--Instance Data Members
s1.sno=100
s1.name="Rossum"
s1.marks=34.56 # here sno,name,marks are called Instance Data members
#Place the Data in S2--Instance Data Members
s2.sno=100
s2.name="Rossum"
s2.marks=34.56 # here sno,name,marks are called Instance Data members
#Display the Content of s1 object
print("First Student Data")
print("\tStudent Number=",s1.sno)
print("\tStudent Name=",s1.name)
print("\tStudent Marks=",s1.marks)
print("---------------------------------------")
#Display the Content of s1 object
print("Second Student Data")
print("\tStudent Number=",s2.sno)
print("\tStudent Name=",s2.name)
print("\tStudent Marks=",s2.marks)
print("---------------------------------------")
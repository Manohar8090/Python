#Program for Reading Employee Values from KBD and Insert them as
# Record in Employee Table--Oracle
#OOPsWithDataBaseEx2.py
import oracledb as orc
class Employee:
    def getempdetails(self):
        self.empno=int(input("Enter the employee number: "))
        self.name=input("Enter the employee name: ")
        self.salary=float(input("Enter the employee salary: "))
        self.cname = input("Enter the employee comp name: ")
    def saveemployeedata(self):
        try:
            con=orc.connect("system/tiger@localhost/orcl")
            cur=con.cursor()
            iq="insert into employee values(%d,'%s',%f,'%s')" %(self.empno,self.name,self.salary,self.cname)
            cur.execute(iq)
            con.commit()
            print("{} Record Inserted".format(cur.rowcount))
        except orc.DatabaseError as db:
            print("Problem in Oracle:",db)

#Main Program
eo=Employee()
eo.getempdetails()
eo.saveemployeedata()


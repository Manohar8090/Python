#Program for adding of Two Numbers by using Classesa dn objects
#NumbersSumEx1.py
class Sum:
    def readvals(self):
        self.a=float(input("Enter the first number: "))
        self.b=float(input("Enter the second number: "))
    def addvals(self):
        self.c=self.a+self.b
    def dispvals(self):
        print("Val of a=",self.a)
        print("Val of b=",self.b)
        print("Sum=",self.c)

#main program
s=Sum()
s.readvals()
s.addvals()
s.dispvals()

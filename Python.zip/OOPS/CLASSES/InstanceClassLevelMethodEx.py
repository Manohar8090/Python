#InstanceClassLevelMethodEx.py
class Student:
    @classmethod
    def getcrs(cls):
        cls.crs = "PYTHON"  # OR Student.crs="PYTHON
        cls.getcity()  # OR Student.getcity() --->Calling Class Level method of same class
    @classmethod
    def getcity(cls):
        cls.city = "HYD"  # OR Student.city="HYD

    def getstuddata(self,objinfo):
        print("Enter {} Object Information:".format(objinfo))
        self.sno=int(input("\tEnter Student Number:"))
        self.name=input("\tEnter Student Name:")
        self.marks=float(input("\tEnter Student Marks:"))
        self.dispstuddata(objinfo) # calling Instance Method
    def dispstuddata(self,objinfo):
        Student.getcrs() #calling Class Level Method
        print("{} Object Information:".format(objinfo))
        print("\tStudent Number=",self.sno)
        print("\tStudent Name=",self.name)
        print("\tStudent Marks=",self.marks)
        print("\tSTUDENT COURSE=",Student.crs)
        print("\tSTUDENT CITY=", Student.city)

#main program
s1=Student()
s2=Student()
print("----------------------------------------")
s1.getstuddata("First")
print("----------------------------------------")
s2.getstuddata("Second")
print("----------------------------------------")
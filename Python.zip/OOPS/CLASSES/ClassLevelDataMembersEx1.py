#Program for Demonstarting the Class Level Data Members
#ClassLevelDataMembersEx1.py
class Student:
    crs="PYTHON" # here crs is Called Class Level data members

#Main Program
print("Student Course=",Student.crs)

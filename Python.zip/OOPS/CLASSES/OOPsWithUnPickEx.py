#Program for Reading the Student Records from File(student.data) by using classes and Objects
# with Un-Pickling Process
#OOPsWithUnPickEx.py
import pickle
class StudentUnPick:
    def readstudentrecords(self):
        with open("E:\\KVR-PYTHON-11AM\\OOPS\\student.data","rb") as fp:
            while(True):
                try:
                    record=pickle.load(fp)
                    record.dispstudvals()
                except EOFError:
                    break

#main program
sp=StudentUnPick()
sp.readstudentrecords()

#Program for storing sno,sname and Marks of Multiple students
#InstanceDataMemberEx1.py
class Student:pass

#Main Program
#Create Two objects of Student
s1=Student()
s2=Student()
print("Content of s1 Object=",s1.__dict__)
print("Content of s2 Object=",s2.__dict__)
print("Number of Values in s1 Object=",len(s1.__dict__))
print("Number of Values in s2 Object=",len(s2.__dict__))
print("---------------------------------------")
#Place the Data in S1--Instance Data Members
s1.sno=100
s1.name="Rossum"
s1.marks=34.56 # here sno,name,marks are called Instance Data members
#Place the Data in S2--Instance Data Members
s2.sno=200
s2.name="Travis"
s2.marks=44.56 # here sno,name,marks are called Instance Data members
#Display the Content of s1 object
print("First Student Data")
print("Number of Values in s1 Object=",len(s1.__dict__))
for dmn,dmv in s1.__dict__.items():
    print("\t{}--->{}".format(dmn,dmv))
print("---------------------------------------")
#Display the Content of s1 object
print("Second Student Data")
print("Number of Values in s2 Object=",len(s2.__dict__))
for dmn in s2.__dict__:
    print("\t{}--->{}".format(dmn,s2.__dict__[dmn]))
print("---------------------------------------")
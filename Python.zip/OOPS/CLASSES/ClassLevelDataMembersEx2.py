#Program for Demonstarting the Class Level Data Members
#ClassLevelDataMembersEx1.py
class Student:pass


#Main Program
Student.crs="PYTHON" # here crs is Called Class Level data members
print("Student Course=",Student.crs)

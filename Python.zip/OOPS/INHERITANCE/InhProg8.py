#InhProg8.py
class GrandParent:
    def getgrandparentprop(self):
        self.gpp=float(input("Enter Grand Parent Property: "))
class Parent:
    def getparentprop(self):
        self.pp=float(input("Enter Parent Property: "))
class Child(GrandParent,Parent):
    def getchildprop(self):
        self.cp=float(input("Enter Child Property: "))
    def gettotprop(self):
        self.tot=self.gpp+self.pp+self.cp
        print("Grand Parent Property=", self.gpp)
        print("Parent Property=",self.pp)
        print("Child Property=", self.cp)
        print("Total Property=", self.tot)

#main program
co=Child()
co.getgrandparentprop()
co.getparentprop()
co.getchildprop()
co.gettotprop()
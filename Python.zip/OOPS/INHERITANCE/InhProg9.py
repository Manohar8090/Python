#InhProg9.py
class Univ:
    def getunivdet(self):
        self.uname=input("Enter University Name: ")
        self.uloc=input("Enter University Location: ")
    def dispunivdet(self):
        print("-" * 50)
        print("University Details")
        print("\tUniversity Name=",self.uname)
        print("\tUniversity Location=",self.uloc)
        print("-"*50)
class College(Univ):
    def getcollegedet(self):
        self.cname=input("Enter College  Name: ")
        self.cloc=input("Enter College Location: ")
    def dispcollegedet(self):
        print("-" * 50)
        print("College Details")
        print("\tCollege Name=",self.cname)
        print("\tCollege Location=",self.cloc)
        print("-"*50)
class Student(College):
    def getstudentdet(self):
        self.sno=int(input("Enter Student Number: "))
        self.sname=input("Enter Student Name: ")
        self.crs=input("Enter Student Course: ")
    def dispstudentdet(self):
        print("-" * 50)
        print("Student Details")
        print("-" * 50)
        print("\tStudent Number=",self.sno)
        print("\tStudent Name=",self.sname)
        print("\tStudent Course=",self.crs)
        print("-" * 50)
#Main Program
so=Student()
so.getstudentdet()
so.getcollegedet()
so.getunivdet()
so.dispunivdet()
so.dispcollegedet()
so.dispstudentdet()


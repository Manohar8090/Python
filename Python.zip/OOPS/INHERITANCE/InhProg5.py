#InhProg5.py
class Parent:
    def getparentprop(self):
        self.pp=float(input("Enter Parent Property: "))
class Child(Parent):
    def getchildprop(self):
        self.cp=float(input("Enter Child Property: "))
    def gettotprop(self):
        self.tot=self.pp+self.cp
        print("Parent Property=",self.pp)
        print("Child Property=", self.cp)
        print("Total Property=", self.tot)

#main program
co=Child()
co.getparentprop()
co.getchildprop()
co.gettotprop()
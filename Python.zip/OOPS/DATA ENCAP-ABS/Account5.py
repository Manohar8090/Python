#Program for Demonstrating the Need of Data Encapsulation
#Account5.py<---Module name
class Account:
    def ____init__(self): # It is not Possible to Hide Constructors bcoz constructors are Magic Method/Dunder methods
        self.acno=100
        self.name="Rossum"
        self.bal=4.5
        self.pin=1234
        self.bname="SBI"


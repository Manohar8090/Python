#Program for Demonstrating the Need of Data Encapsulation
#Account3.py<---Module name
class Account:
    def __getaccdet(self):
        self.acno=100
        self.name="Rossum"
        self.bal=4.5
        self.pin=1234
        self.bname="SBI"


#program for Demonstrating the need of Data Abstraction
#Others3.py<---Program
from Account4 import Account
#This Program for Will Not Execute bcoz Account Class made as Encapsulated
ac=Account() # Object Creation
ac.getaccdet()
print("-"*50)
print("Account Number=",ac.acno)
print("Account Holder Name=",ac.name)
print("Account Balance=",ac.bal)
print("Account Pin=",ac.pin)
print("Account Holder Branch Name=",ac.bname)
print("-"*50)
#Program for Demonstrating the Need of Abstraction
#Others5.py
from Account5 import Account
ac=Account()
ac.____init__()
print("-"*50)
print("Account Number=",ac.acno)
print("Account Holder Name=",ac.name)
print("Account Balance=",ac.bal)
print("Account Pin=",ac.pin)
print("Account Holder Branch Name=",ac.bname)
print("-"*50)
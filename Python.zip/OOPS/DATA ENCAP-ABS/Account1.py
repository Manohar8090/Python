#Program for Demonstrating the Need of Data Encapsulation
#Account1.py<---Module name
class Account:
    def __init__(self):
        self.__acno=100
        self.name="Rossum"
        self.__bal=4.5
        self.__pin=1234
        self.bname="SBI"


#program for Demonstrating the need of Data Abstraction
#Others2.py<---Program
from Account2 import Account
ac=Account() # Object Creation
ac.getaccdet()
print("-"*50)
#print("Account Number=",ac.acno)
print("Account Holder Name=",ac.name)
#print("Account Balance=",ac.bal)
#print("Account Pin=",ac.pin)
print("Account Holder Branch Name=",ac.bname)
print("-"*50)
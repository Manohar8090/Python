#Program for Demonstrating the Destructor
#GCEx2.py
import sys,time,gc
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor:{}".format(id(self)))
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")
	def  __del__(self):
		print("GC calls __del__() for De-Allocating the Memory Space:{}".format(id(self)))
		global totmemspace
		totmemspace=totmemspace-sys.getsizeof(self)
		print("\tNow Available Memory Space=",totmemspace)

#Main Program
print("Program Execution Started")
print("Initially, Is GC running :",gc.isenabled()) # True
gc.disable()
e1=Employee(100,"RS") # Object Creation
e2=Employee(200,"TR") # Object Creation
e3=Employee(300,"DR") # Object Creation
print("Now, Is GC running after disable() :",gc.isenabled()) # False
#Computer the total memory space of object e1 , e2 and e3
totmemspace=sys.getsizeof(e1)+sys.getsizeof(e2)+sys.getsizeof(e3)
print("Total Memory Space of all objects=",totmemspace) # 144
print("Program Execution Ended")
time.sleep(5)

#Program for Demonstrating the Destructor
#DestEx6.py
import time
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor")
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")
	def  __del__(self):
		print("GC calls __del__() for De-Allocating the Memory Space:")

#Main Program
print("Program Execution Started")
e1=Employee(100,"RS") # Object Creation
e2=e1 # Deep Copy
e3=e1 # Deep Copy
print("No Longer Interested in use of o1 Object")
time.sleep(5)
del e1 #GC will not  call Its Destructor Forcefully bcoz Still e2 and e3 points to Object Memory space
print("No Longer Interested in use of o2 Object")
time.sleep(5)
del e2 #  #GC will not  call Its Destructor Forcefully bcoz Still  e3 points to Object Memory space
time.sleep(5)
print("No Longer Interested in use of o3 Object")
del e3 # GC will   call Its Destructor Forcefully
time.sleep(5)
print("Program Execution Ended")

#Program for Demonstrating the Destructor
#DestEx5.py
import time
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor")
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")
	def  __del__(self):
		print("GC calls __del__() for De-Allocating the Memory Space:")

#Main Program
print("Program Execution Started")
e1=Employee(100,"RS") # Object Creation
e2=e1 # Deep Copy
e3=e1 # Deep Copy
print("Program Execution Ended")
time.sleep(5)

#Program for Demonstrating the Destructor
#Non-DestEx1.py
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor")
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")

#Main Program
print("Program Execution Started")
e1=Employee(100,"RS") # Object Creation
e2=Employee(200,"TR") # Object Creation
e3=Employee(300,"DR") # Object Creation
print("Program Execution Ended")

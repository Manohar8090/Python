#Program for Demonstrating  whether  GC runs or not
#GCEx1.py
import gc
print("-----------------------------------------------------------------")
print("Program Execution Started")
print("Initially, Is GC running :",gc.isenabled()) # True
a=10
gc.disable()
b=20
c=a+b
print("\tVal of a=",a)
print("Now, Is GC running after disable() :",gc.isenabled()) # False
gc.enable()
print("\tVal of b=",b)
print("\tSum==",c)
print("Now, Is GC running after enable() :",gc.isenabled()) # True
print("Program Execution Ended")
print("-----------------------------------------------------------------")
#Program for Demonstrating the Destructor
#DestEx1.py
import time
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor:{}".format(id(self)))
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")
	def  __del__(self):
		print("GC calls __del__() for De-Allocating the Memory Space:{}".format(id(self)))

#Main Program
print("Program Execution Started")
e1=Employee(100,"RS") # Object Creation
e2=Employee(200,"TR") # Object Creation
e3=Employee(300,"DR") # Object Creation
print("Program Execution Ended")
time.sleep(5)

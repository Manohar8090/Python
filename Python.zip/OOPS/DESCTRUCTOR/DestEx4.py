#Program for Demonstrating the Destructor
#DestEx4.py
import sys,time
class Employee:
	def __init__(self,eno,ename):
		print("I am from Parameterized Constructor:{}".format(id(self)))
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
		print("------------------------------------------------------")
	def  __del__(self):
		print("GC calls __del__() for De-Allocating the Memory Space:{}".format(id(self)))


#Main Program
print("Program Execution Started")
e1=Employee(100,"RS") # Object Creation
print("No Longer Interested in use of o1 Object")
time.sleep(5)
e1=None # Makes the GC to call Its Destructor Forcefully.
time.sleep(5)
e2=Employee(200,"TR") # Object Creation
print("No Longer Interested in use of o2 Object")
time.sleep(5)
e2=None # Makes the GC to call Its Destructor Forcefully.
time.sleep(5)
e3=Employee(300,"DR") # Object Creation
print("No Longer Interested in use of o3 Object")
time.sleep(5)
e3=None # Makes the GC to call Its Destructor Forcefully.
print("Program Execution Ended")

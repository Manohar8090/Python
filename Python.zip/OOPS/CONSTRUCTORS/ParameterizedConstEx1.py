#Program for Demonstrates Paramerized Constructor
#ParameterizedConstEx1.py
class Test:
    def __init__(self,a,b):
        print("I am from Paramerized Constructor")
        self.a=a
        self.b=b
        print("\tVal of a=",a)
        print("\tVal of b=",b)
        print("-----------------------------------------")
#main program
t1=Test(10,20) # Object Creation-- #Object Creation--Makes the PVM to Call Paramerized Constructor Implcitly
t2=Test(100,200) # Object Creation-- #Object Creation--Makes the PVM to Call Paramerized Constructor Implcitly
t3=Test(1000,2000) # Object Creation-- #Object Creation--Makes the PVM to Call Paramerized Constructor Implcitly
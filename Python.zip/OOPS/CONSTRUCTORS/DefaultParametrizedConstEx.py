#This Program Demonstrates Both Default and parameterized Constructor
#DefaultParametrizedConstEx.py
class Test:
    def __init__(self,a=1,b=2):
        print("I am from Default / Parameterized Constructor")
        self.a=a
        self.b=b
        print("\tVal of a=",self.a)
        print("\tVal of b=",self.b)
        print("-----------------------------------------")
#main Program
t1=Test() # Object Creation-makes the PVM to Call Default Constructor
t2=Test(100,200)# Object Creation-makes the PVM to Call Parameterized Constructor
t3=Test(1000) # Object Creation-makes the PVM to Call Parameterized Constructor
t4=Test(b=1000) # Object Creation-makes the PVM to Call Parameterized Constructor
t5=Test(b=300,a=400) # Object Creation-makes the PVM to Call Parameterized Constructor
t7=Test(a=300,b="KVR")  # Object Creation-makes the PVM to Call Parameterized Constructor


#ConstEx1.py
class Employee:
    def __init__(self, empno, empname):  # Parameterized constructor
        print("I am from Parameterized constructor:")
        self.eno = empno
        self.ename = empname
        print("\tEmp Number=", self.eno)
        print("\tEmp Name=", self.ename)
        print("------------------------------------")

#main Program
e1 = Employee(100, "RS")  #Object Creation--Makes the PVM to Call Parameterized Constructor Implcitly
e2 = Employee(200, "TR")  #Object Creation--Makes the PVM to Call Parameterized Constructor Implcitly
e3 = Employee(300, "DR")  #Object Creation--Makes the PVM to Call Parameterized Constructor Implcitly

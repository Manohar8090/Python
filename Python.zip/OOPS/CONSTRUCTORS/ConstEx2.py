#ConstEx2.py
class Employee:
    def __init__(self): # default constructor
        print("I am from default constructor:")
        self.eno=100
        self.ename="RS"
        print("\tEmp Number=",self.eno)
        print("\tEmp Name=",self.ename)
        print("------------------------------------")

#main Program
e1=Employee() #Object Creation--Makes the PVM to Call Default Constructor Implcitly
e2=Employee()#Object Creation--Makes the PVM to Call Default Constructor Implcitly
e3=Employee()#Object Creation--Makes the PVM to Call Default Constructor Implcitly

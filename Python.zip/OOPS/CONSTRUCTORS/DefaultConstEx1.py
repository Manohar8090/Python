#Program for Demonstrates Defalult Constructor
#DefaultConstEx1.py
class Test:
    def __init__(self):
        print("I am from Default Constructor")
        self.a=10
        self.b=20
        print("\tVal of a=",self.a)
        print("\tVal of b=", self.b)
        print("-----------------------------------------")

#main program
t1=Test() # Object Creation-- #Object Creation--Makes the PVM to Call Default Constructor Implcitly
t2=Test() # Object Creation-- #Object Creation--Makes the PVM to Call Default Constructor Implcitly
t3=Test() # Object Creation-- #Object Creation--Makes the PVM to Call Default Constructor Implcitly
#Non-ConstEx.py
class Employee:
    def getempdata(self):
        self.eno=100
        self.ename="RS"

#Main Program
e1=Employee()
print("Content of e1 before placing the data=",e1.__dict__) # { }
#By using an Instance Method
e1.getempdata() # calling the method Explcitly---
print("Content of e1 after placing the Data=",e1.__dict__) # {eno:100,ename:"RS"}
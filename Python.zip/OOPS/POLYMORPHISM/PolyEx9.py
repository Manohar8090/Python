#PolyEx9.py
class Cicrle:
    def area(self): # Original Method
        self.r=float(input("Enter the radius: "))
        self.ac=3.14*self.r**2
        print("Area of circle is:",self.ac)
class Square(Cicrle):
    def area(self):#Overridden Method
        self.s=float(input("Enter Side Value: "))
        self.sa=self.s**2
        print("Area of square is:",self.sa)
        print("---------------------------------")

class Rect(Square):
    def area(self):#Overridden Method
        self.L=float(input("Enter Rectangle Length: "))
        self.B=float(input("Enter Rectangle Breadth: "))
        self.ra=self.L*self.B
        print("Area of rectangle is:",self.ra)
        print("---------------------------------")
        Square.area(self)
        Cicrle.area(self)


#Main Program
ro=Rect()
ro.area()
print("---------------OR-----------------")
Rect().area()





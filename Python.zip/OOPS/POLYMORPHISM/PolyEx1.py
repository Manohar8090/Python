#PolyEx1.py
class C1:
    def disp(self): # Original Method
        print("C1--disp()-original")
class C2(C1):
    def disp(self): # Overridden Method
        print("C2--disp()--Overridden")
        super().disp()
class C3(C2):
    def disp(self): # Overridden Method
        print("C3--disp()--Overridden")
        super().disp()

#main program
o3=C3()
o3.disp()

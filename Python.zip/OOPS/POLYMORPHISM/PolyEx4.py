#PloyEx4.py
class C1:
    def __init__(self): # Original Constructor
        print("C1--__init__()-original")
class C2(C1):
    def __init__(self):  # Overridden Constructor
        print("C2--__init__()-Overridden")
        super().__init__()

class C3(C2):
    def __init__(self):  # Overridden Constructor
        print("C3--__init__()-Overridden")
        super().__init__()

#Main Program
o3=C3() # Object Creation




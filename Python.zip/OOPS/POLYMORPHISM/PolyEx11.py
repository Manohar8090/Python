#PolyEx10.py
class Circle:
    def __init__(self): # Original Constructor
        self.r=float(input("Enter the radius: "))
        self.ac=3.14*self.r**2
        print("Area of circle is:",self.ac)
class Square:
    def __init__(self):#Original Constructor
        self.s=float(input("Enter Side Value: "))
        self.sa=self.s**2
        print("Area of square is:",self.sa)
        print("---------------------------------")
class Rect(Circle,Square):
    def __init__(self):#Overridden  Constructor
        self.L=float(input("Enter Rectangle Length: "))
        self.B=float(input("Enter Rectangle Breadth: "))
        self.ra=self.L*self.B
        print("Area of rectangle is:",self.ra)
        print("---------------------------------")
        Square.__init__(self)
        Circle.__init__(self)


#Main Program
ro=Rect()
print("------------------OR----------------")
Rect()


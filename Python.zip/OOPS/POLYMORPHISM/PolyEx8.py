#PolyEx7.py
class C1:
    def __init__(self): # Original Const
        print("C1--__init__()-original")
class C2:
    def __init__(self):  # Original Const
        print("C2--__init__()-original")
class C3(C2,C1):
    def __init__(self): # Overridden Const
        print("C3--__init__()-Overridden")
        C1.__init__(self)
        C2.__init__(self) # OR super().__init__()

#main program
o3=C3()



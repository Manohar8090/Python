#PloyEx3.py
class C1:
    def __init__(self): # Original Constructor
        print("C1--__init__()-original")
class C2(C1):
    def __init__(self):  # Overridden Constructor
        print("C2--__init__()-Overridden")
        super().__init__()

#Main Program
o2=C2() # Object Creation




#PolyEx7.py
class C1:
    def disp(self): # Original Method
        print("C1--disp()-original")
class C2:
    def disp(self): # Original Method
        print("C2--disp()--original")
class C3(C1,C2):
    def disp(self):  # Overridden Method
        print("C3--disp()--Overridden")
        C1.disp(self)
        C2.disp(self)

#main program
o3=C3()
o3.disp()


#program for Inserting the Employee Record in Employee Table
#MySQLRecordInsertEx.py
import mysql.connector as mc
def recordinsert():
    while(True):
        try:
            conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root",
                          database="batch11am") #Step-2
            curobj=conobj.cursor()
            # accept the employee values from Key board
            print("-"*40)
            empno=int(input("Enter Employee Number: "))
            empname=input("Enter Employee Name: ")
            empsal=float(input("Enter Employee Salary: "))
            empcompname=input("Enter Employee Company Name: ")
            print("-" * 40)
            iq="insert into employee values(%d,'%s',%f,'%s')" % (empno,empname,empsal,empcompname)
            curobj.execute(iq)
            conobj.commit()
            print("{} Record Inserted".format(curobj.rowcount))
            print("-" * 40)
            ch=input("Do you want to insert another record(yes/no)")
            if(ch.lower()=="no"):
                print("Thx for using this program")
                break
        except mc.DatabaseError as db:
            print("Problem in MySQL: ",db)
        except ValueError:
            print("Don't Enter alnums,strs and symbols for empno and Sal")

#Main Program
recordinsert()

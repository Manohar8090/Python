#MySQLTestEx2.py
import mysql.connector
import mysql.connector as mc
try:
    conobj=mc.connect(host="127.0.0.1",
                      user="root",
                      passwd="root")
    print("Python Program got Connection from MySQL")
except mc.DatabaseError as db:
    print("Problem in MySQL:", db)

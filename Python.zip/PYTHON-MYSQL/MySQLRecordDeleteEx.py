#program for deleting the record from Employee table
#MySQLRecordDeleteEx.py
import mysql.connector as mc
def recorddelete():
    while(True):
        try:
            conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root",
                          database="batch11am") #Step-2
            curobj=conobj.cursor()
            # accept the employee Number for deleting employee record
            print("-"*40)
            empno=int(input("Enter Employee Number for deleting employee record: "))
            dq="delete from employee where eno=%d"
            curobj.execute(dq %empno)
            conobj.commit()
            if(curobj.rowcount>0):
                print("{} Record Deleted".format(curobj.rowcount))
            else:
                print("Employee Number does not exist")
            print("-" * 40)
            ch = input("Do you want to Delete another record(yes/no)")
            if (ch.lower() == "no"):
                print("Thx for using this program")
                break
        except mc.DatabaseError as db:
            print("Problem in MySQL: ",db)
#Main Program
recorddelete()

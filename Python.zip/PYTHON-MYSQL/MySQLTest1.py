#MySQLTestEx1.py
import mysql.connector as mc
conobj=mc.connect(host="localhost",
                  user="root",
                  passwd="root")
print("Python Program got Connection from MySQL")

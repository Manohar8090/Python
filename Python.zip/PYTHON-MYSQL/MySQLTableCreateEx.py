#program for Creating employee Table
#MySQLTableCreateEx.py
import mysql.connector as mc # Step-1
def tablecreate():
    try:
        conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root",
                          database="batch11am") #Step-2
        curobj=conobj.cursor() #Step-3
        #step-4
        tc="create table student(sno int primary key,name varchar(10) not null , marks float not null,cname varchar(10) not null)"
        curobj.execute(tc)
        print("Table created successfully in MySQL")
    except mc.DatabaseError as db:
        print("Problem in MySQL:", db)
#main program
tablecreate()
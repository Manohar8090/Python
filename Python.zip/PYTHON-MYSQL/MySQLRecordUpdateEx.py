#program for updating the employee salary based on employee number
#MySQLRecordUpdateEx.py
import mysql.connector as mc
def recordupdate():
    while(True):
        try:
            conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root",
                          database="batch11am") #Step-2
            curobj=conobj.cursor()
            # accept the employee Number for Updating emp salary
            print("-"*40)
            empno=int(input("Enter Employee Number for Updating emp sal: "))
            empsal=float(input("Enter New Employee Salary: "))
            print("-" * 40)
            uq="update employee set sal=%f where eno=%d"
            curobj.execute(uq % (empsal,empno))
            conobj.commit()
            if(curobj.rowcount>0):
                print("{} Record Updated".format(curobj.rowcount))
            else:
                print("Employee Number does not exist")
            print("-" * 40)
            ch = input("Do you want to update another record(yes/no)")
            if (ch.lower() == "no"):
                print("Thx for using this program")
                break
        except mc.DatabaseError as db:
            print("Problem in MySQL: ",db)

#Main Program
recordupdate()

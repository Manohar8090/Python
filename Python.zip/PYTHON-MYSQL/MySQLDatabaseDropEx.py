#program for Droping the Database
#MySQLDatabaseDropEx.py
import mysql.connector as mc # Step-1
def databasedrop():
    try:
        conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root") #Step-2
        curobj=conobj.cursor() #Step-3
        #step-4
        dcq="drop database batch7am"
        curobj.execute(dcq)
        print("Database Dropped Sucessfully from MySQL-verify")
    except mc.DatabaseError as db:
        print("Problem in MySQL:", db)
#main program
databasedrop()
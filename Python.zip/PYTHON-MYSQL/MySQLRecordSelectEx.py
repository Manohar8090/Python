#program for Obtaining Records with Column Names
#MySQLRecordSelectEx.py
import mysql.connector as mc
def recordswithcolumnsselect():
    try:
        conobj=mc.connect(host="127.0.0.1",
                          user="root",
                          passwd="root",
                          database="batch11am") #Step-2
        curobj=conobj.cursor()
        sq="select * from %s" %input("Enter Table Name:")
        curobj.execute(sq)
        records=curobj.fetchall()
        #Get Column Names
        print("-"*50)
        colinfo=curobj.description
        for col in colinfo:
            print("\t{}".format(col[0]),end="\t")
        print()
        print("-" * 50)
        #Get the Records
        if(len(records)==0):
            print("\tTable does not contain any records.")
        else:
            for record in records:
                for val in record:
                    print("\t{}".format(val), end="\t")
                print()
        print("-" * 50)

    except mc.DatabaseError as db:
        print("Table Does not Exist")

#Main Program
recordswithcolumnsselect()
